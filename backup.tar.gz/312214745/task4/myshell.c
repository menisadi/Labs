#include <unistd.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <sys/types.h>
#include <sys/wait.h>
#include "LineParser.h"
#define MAX_LENGHT 2048

typedef struct PairsNode {
  char* name;
  char* value;
  struct PairsNode *next;
  }PairsNode;
PairsNode *headPairs;
PairsNode *tailPairs; 
  
  int initPairsNode(void) { 
  headPairs=(PairsNode *) malloc(sizeof *headPairs);
  tailPairs=(PairsNode *) malloc(sizeof *headPairs);
  headPairs->next = tailPairs; tailPairs->next = tailPairs;
  return 0;
}

PairsNode *set(char* n,char* v) { 

  PairsNode *ptr;
  PairsNode *t;
  ptr=headPairs;
  while (ptr->next != tailPairs){
    
    if((ptr!=headPairs)&&(strcmp(ptr->name,n)==0)){
     strcpy( ptr->value,v);
     return headPairs;
    }
    ptr = ptr->next;}
  t=(PairsNode *) malloc(sizeof *t);
        t->value= malloc(MAX_LENGHT);
        t->name= malloc(MAX_LENGHT);
   strcpy( t->value,v);
    strcpy( t->name,n);
  t->next = tailPairs;
  ptr->next = t;

   return ptr;
    
} 
  
  void deletePa(PairsNode *ptr) {


  free(ptr->name);
  free(ptr->value);
  free(ptr);
  }

  

int printenviroment(void){ 
  PairsNode *ptr=headPairs->next;
  while (ptr->next != tailPairs){
    printf("the name IS:%s && the value IS:%s\n",ptr->name,ptr->value);
    ptr = ptr->next;
}
    printf("the name IS:%s && the value IS:%s\n",ptr->name,ptr->value);

return 0;}



int replaceArg(cmdLine *cm){
  int i=0;
  int didReplace=0;
  int isfound=0;
  PairsNode *ptr=headPairs->next;
  for(i=0;i<cm->argCount;i++){
    if(cm->arguments[i][0]=='$'){
       char* name1=strstr(cm->arguments[i],"$")+1;
   ptr=headPairs->next;
      while ((ptr != tailPairs)&&(isfound==0)){
  if(strcmp(ptr->name,name1)==0){
    didReplace=replaceCmdArg(cm,i,ptr->value);
    if(didReplace==0){
       printf("error in replacing argument of $ try again\n");
       return 0;
    }
    isfound=1;
  }
  ptr = ptr->next;
  
      }
    }
  }
  return 0;
}


int renamePairs(char* name,char* newName){ 
    PairsNode *ptr=headPairs->next;
    int isfound=0;
    while ((ptr != tailPairs)&&(isfound==0)){
      if(strcmp(ptr->name,name)==0){
         strcpy( ptr->name,newName);
         isfound=1;
       }
    ptr = ptr->next;
}
if(isfound==0){
       printf("error vairable doesnt exist : rename\n");
  
}
return 0;
}


int deletePairs(char* name){ 
    PairsNode *ptr=headPairs->next;
    int isfound=0;
     PairsNode *ptrp=headPairs->next;
    while ((ptr != tailPairs)&&(isfound==0)){
      if(strcmp(ptr->name,name)==0){
  if(ptr==headPairs->next){
    headPairs->next=ptr->next;
  }
  else{
  ptrp->next=ptr->next;}
  deletePa(ptr);
         isfound=1;
       }
       ptrp=ptr;
      ptr = ptr->next;
}

if(isfound==0){
       printf("error vairable doesnt exist : rename\n");
  
}


return 0;
}



  
struct node {
  char* value;
  struct node *next;
  };

struct node *head;
struct node *tail;

int init(void) {
  head=(struct node *) malloc(sizeof *head);
  tail=(struct node *) malloc(sizeof *head);
  head->next = tail; tail->next = tail;
  return 0;
}

struct node *append(char* v) {

  struct node *ptr;
  struct node *t;
  ptr=head;
  while (ptr->next != tail) ptr = ptr->next;
  t=(struct node *) malloc(sizeof *t);
    t->value= malloc(MAX_LENGHT);
   strcpy( t->value,v);
  t->next = tail;
  ptr->next = t;
  ptr=head;
  return ptr;
    
}

void delete(struct node *ptr) {
  struct node *t;
  t = ptr->next;
  ptr->next = ptr->next->next;
  free(t);
  free(ptr->value);
  }


  void deletePairsList(){
    PairsNode *ptr=headPairs->next;
    struct node *ptr1=head->next ;
      struct node *t1=0;
      PairsNode *t=0;
     while (ptr != tailPairs){
       t= ptr->next;
      free(ptr->value);
      free(ptr->name);
    free(ptr);
       ptr=t;
  }
    while (ptr1 != tail){
       t1= ptr1->next;
    free(ptr1->value);
    free(ptr1);
      ptr1=t1;
 }
free(head);
free(headPairs);
free(tail);
free(tailPairs);
 
  }
 /*******************    up are the linked list code          *********************/ 

void printPipes(int **pipes){
  int j=0;
while(pipes[j]!=NULL){
  printf("the first element %d == the second element %d \n",pipes[j][0],pipes[j][1] );
  j++;
}

}

int **createPipes(int nPipes){
int** pipes= malloc((nPipes+1)*((sizeof(int))*2));
int j=0;
while(j<nPipes){
    printf(" the pipe number : %d\n", j);
pipes[j]=malloc(2*(sizeof(int)));/***     here    ****/
 pipes[j][0] = 0;
 pipes[j][1] = 0;
j++;
}
pipes[j]=NULL;
  printf(" the j : %d\n", j);
j=0;
while(j<nPipes){
 if(pipe(pipes[j])!=0){
   printf("error pipe didnt work function createPipes \n");
   exit(0);
 }
j++;
}

return pipes;
} 

void releasePipes(int **pipes, int nPipes){
int j=0;
while(j<nPipes){
pipes[j][0]=0;
pipes[j][1]=0;
free(pipes[j]);
j++;
}
free(pipes[j]);
free(pipes);
}




int *rightPipe(int **pipes, cmdLine *pCmdLine) {
  int index=pCmdLine->idx;
  printf("the index: %d\n", index+1);
  if(pipes[index+1]==NULL){/*    here   */
  return NULL;
}
  int j=0;
  while(j!=index){
    j++;
  }

  if((pipes[j]!=NULL)&&(pipes[j+1]!=NULL)){
  return pipes[j];}
  else {
    printf("rightPipe is not found \n");
    return 0;
  }
}







int *leftPipe(int **pipes, cmdLine *pCmdLine) {
  int index=pCmdLine->idx;
    if(index==0){
    return NULL;
  }
  int j=0;
  while(j!=index){
    j++;
  }
  if(pipes[j]!=NULL){
  return pipes[j-1];}
  else {
    printf("leftPipe is not found \n");
    return 0;
  }
}








  
void execute(cmdLine *pCmdLine) {
  int pID = fork();
  if(pCmdLine!=0){
 if(pID==0){
   if(pCmdLine->inputRedirect !=NULL){
     fclose(stdin);
     fopen(pCmdLine->inputRedirect,"r+");
   }
      if(pCmdLine->outputRedirect !=NULL){
     fclose(stdout);

     fopen(pCmdLine->outputRedirect,"w+");
   }
   
   
 if(execvp(pCmdLine->arguments[0],pCmdLine->arguments)<0){
   perror("error execv didnt work");
   exit(EXIT_FAILURE);}
    freeCmdLines(pCmdLine);
deletePairsList();

}
 else if (pID < 0) {
    printf("error in fork \n");
    exit(0);
 }
 else if(pCmdLine->blocking==1 ){
   waitpid(pID,0,0);
 }

    
  }
}


int creatPip(cmdLine *pCmdLine){
  printf("we entered creatPip \n");
  int fd[2]={0,0};
 if(pipe(fd)!=0){
   printf("error pipe didnt work \n");
   exit(0);
 }
 int pID = fork();
  if(pID==0){
      close(1);
     if( dup(fd[1])==-1){
          printf("error dup fd[1] \n");
	  deletePairsList();
        freeCmdLines(pCmdLine);
       exit(0);
     }
      close(fd[1]);
    execute(pCmdLine);
    deletePairsList();
    freeCmdLines(pCmdLine);
       exit(0);

}
 else {
   if(pID<0){
       perror(" creatPip error execv didnt work");
        exit(EXIT_FAILURE);}
   
    close(fd[1]);
    int  pID2 = fork();
      if(pID2==0){
      close(0);
   if( dup(fd[0])==-1){
            printf("error dup fd[0] \n");
	    deletePairsList();
      freeCmdLines(pCmdLine);
       exit(0);
     }
      close(fd[0]);
    execute(pCmdLine->next);
    deletePairsList();
     freeCmdLines(pCmdLine);
    exit(0);

} else{
     if(pID2<0){
       perror(" creatPip error fork didnt work");
       deletePairsList();
        freeCmdLines(pCmdLine);
        exit(EXIT_FAILURE);}
       close(fd[0]);
        waitpid(pID2,0,0);
    
}
  waitpid(pID,0,0);
  }
  
return 0;
}









int main (int argc , char* argv[], char* envp[])                            
{ 
 cmdLine* cm=0;
  cmdLine* cm2=0;
    cmdLine* cm1=0;
  cm = parseCmdLines("ls | tee | cat | more") ;
  cm1=cm;
  while(cm1->next!=NULL){
       printf("the index *********%d\n",cm1->idx);
       cm1=cm1->next;
  }
  cm2=(cm->next)->next;
  int** pipes=createPipes(3);
   printPipes(pipes);
   printf("=============================================\n");
  if(leftPipe(pipes,cm)!=NULL){
    printf("leftpipe didnt work\n");
  }
    if(rightPipe(pipes,cm2)!=NULL){
    printf("rightpipe didnt work\n");
  }

int* arr1=leftPipe(pipes,cm->next);
int* arr2=rightPipe(pipes,cm->next);
  printf("the first element %d == the second element %d \n",arr1[0],arr1[1] );
  printf("the first element %d == the second element %d \n",arr2[0],arr2[1] );
  printf("it worked :)\n");

  execvp(cm->arguments[0],cm->arguments);
   releasePipes(pipes,3);
   freeCmdLines(cm);
  return 0;
}
















 int mycode(){ 
  int flagN=0;
  int j=0;
  int i=0;
  struct node *history;
  init();
  initPairsNode();

  int er=0;
  cmdLine* cm=0;
  char line[2048];
 int PATH_MAX=100;
 char buf[PATH_MAX];
 getcwd(buf, PATH_MAX);
 printf("the path is:%s", buf);
 fgets(line,2048, stdin);
cm = parseCmdLines(line) ;
replaceArg(cm);
while(1){
  if((cm!=0)&&(strcmp(cm->arguments[0],"quit")!=0)){
    if(flagN==0){
       line[strlen(line)-1]=0;}
       flagN=0;
         append(line);
  if(strcmp(cm->arguments[0],"cd")==0){
   er=chdir(cm->arguments[1]); 
   if(er!=0){
    freeCmdLines(cm);
     deletePairsList();   
      perror("error cd didnt work");
      exit(EXIT_FAILURE);
   }
  }
  else{
    if((strcmp(cm->arguments[0],"history")!=0)&&(cm->arguments[0][0]!='!')){
     if( strcmp(cm->arguments[0],"set")==0){
       if(cm->argCount>=2){
       set(cm->arguments[1],cm->arguments[2]);
     }}
     else{if(strcmp(cm->arguments[0],"env")==0){
       printenviroment();  
     }
     else{if(strcmp(cm->arguments[0],"rename")==0){
      renamePairs(cm->arguments[1],cm->arguments[2]);
     }
     else{if(strcmp(cm->arguments[0],"delete")==0){
           deletePairs(cm->arguments[1]);
     }

else{

  if(cm->next!=NULL){
creatPip(cm);
  }
  else{
   execute(cm);}}}}
  }}}}
 if((cm!=0)&&(strcmp(cm->arguments[0],"quit")==0)){
       freeCmdLines(cm);
     deletePairsList();
      exit(0);
    }
    history=head->next;
    j=0;
 if((cm!=0)&&(strcmp(cm->arguments[0],"history")==0)){
  while (history != tail) {
  printf("%d:%s\n",j,history->value);
  j++;
  history=history->next;
  }
  }
 if((cm!=0)&&(cm->arguments[0][0]=='!')){
   
  i=atoi(strstr(cm->arguments[0],"!")+1);
  j=0;
  history=head->next;
 while ((history != tail)&&(flagN==0)) {
  if(i==j){
    strcpy(line,history->value);
    cm = parseCmdLines(line) ;
     freeCmdLines(cm);
  printf("%d:%s\n",j,history->value);
 flagN=1;
    j++;
  }
  j++;
  history=history->next;
  }
   if((flagN==0)|(i<0)){
     perror("index out of bounds; History List");
      i=-1;
  }
  
 }
if(flagN==0){
getcwd(buf, PATH_MAX);
printf("the path is:%s", buf);
freeCmdLines(cm);
fgets(line,2048, stdin);
cm = parseCmdLines(line) ;
replaceArg(cm);
}}
deletePairsList();
freeCmdLines(cm);
return 0;
}